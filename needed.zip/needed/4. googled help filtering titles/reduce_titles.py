import pandas as pd
import re

# pool rebuild
isco = pd.read_csv("isco_clean.csv", dtype=str)
occ = pd.read_csv("esco_occupations_clean.csv", dtype=str)

pool1 = isco.rename(columns={"isco_title": "label"})[["isco_code", "label"]]
pool2 = occ.rename(columns={"occupation": "label"})[["isco_code", "label"]]
alt = occ[["isco_code", "altLabels"]].dropna()
alt["label"] = alt["altLabels"].str.split("\n")
alt = alt.explode("label")[["isco_code", "label"]]
pool = pd.concat([pool1, pool2, alt]).dropna()

# a function that tidies a job title
remove_words = ["senior", "sr", "junior", "jr", "lead", "principal", "staff",
                "associate", "intern", "trainee", "head of", "chief",
                "ii", "iii", "iv"]

def tidy(title):
    t = str(title).lower()
    t = re.sub(r"\(.*?\)|\[.*?\]", " ", t)        # remove text in brackets
    t = re.split(r" - | – | — | \| |,|/", t)[0]   # keep only the part before - | , /
    t = re.sub(r"[^a-z ]", " ", t)                # keep letters only
    for w in remove_words:
        t = re.sub(r"\b" + w + r"\b", " ", t)     # remove seniority words
    t = re.sub(r"\s+", " ", t).strip()            # tidy spaces
    return t

# tidy the pool the same way, so the two can be matched fairly
pool["label"] = pool["label"].apply(tidy)
pool = pool[pool["label"] != ""].drop_duplicates("label").reset_index(drop=True)

# tidy the job titles
jobs = pd.read_csv(r"C:\Users\waize\PyCharmMiscProject\jobs_all.csv")
jobs["title_clean"] = jobs["job_title"].apply(tidy)
jobs = jobs[jobs["title_clean"] != ""]

counts = jobs["title_clean"].value_counts()
print("unique titles after tidying:", len(counts))

# how much of the data do the most common titles cover?
total = len(jobs)
for n in [500, 1000, 3000, 5000, 10000]:
    share = counts.head(n).sum() / total * 100
    print("top", n, "titles cover", round(share, 1), "% of postings")

# exact match after tidying
titles = pd.DataFrame({"title_clean": counts.index, "postings": counts.values})
exact = titles.merge(pool, left_on="title_clean", right_on="label", how="left")
matched = exact[exact["isco_code"].notna()]
print("exact matched titles:", len(matched))
print("postings covered by exact matches:", round(matched["postings"].sum() / total * 100, 1), "%")

print()
print("20 most common tidied titles:")
print(counts.head(20))

titles.to_csv("titles_tidied.csv", index=False)