import pandas as pd
import re

lookup = pd.read_csv("title_to_isco.csv", dtype=str)
titles = pd.read_csv("titles_tidied.csv")

# first rule that matches wins, so the order matters
rules = [
    (["data scientist", "data science", "machine learning", "deep learning", "nlp",
      "mlops", "ml ops", "artificial intelligence", "ai engineer", "ai scientist",
      "ai researcher", "generative ai", "cientista de dados", "cientifico de datos"], "2511"),
    (["data engineer", "data engineering", "big data", "bigdata", "etl", "dataops",
      "data ops", "data platform", "data pipeline", "data infrastructure",
      "data integration", "ingeniero de datos", "engenheiro de dados"], "2511"),
    (["data analyst", "data analytics", "data analysis", "data analist", "data analyste",
      "analista de datos", "datenanalyst", "bi analyst", "bi developer", "bi engineer",
      "business intelligence", "reporting analyst", "insights analyst",
      "insight analyst", "analytics analyst", "power bi", "tableau", "qlik", "looker"], "2511"),
    (["business system", "systems analyst", "it analyst", "ict analyst"], "2511"),
    (["business analyst"], "2421"),
    (["database", "data warehouse", "data modeler", "data modeller", "dba"], "2521"),
    (["statistician", "statistical analyst"], "2120"),
    (["web developer"], "2513"),
    (["software", "developer", "programmer", "full stack", "fullstack", "frontend",
      "front end", "backend", "back end", "devops", "desarrollador", "d veloppeur"], "2512"),
]

# titles with these words keep the AI's answer (they are managers, consultants, etc.)
skip_words = ["manager", "director", "vp", "avp", "svp", "head", "consultant",
              "instructor", "trainer", "internship", "intern"]

def apply_rules(title):
    for w in skip_words:
        if re.search(r"\b" + w + r"\b", title):
            return None
    for keys, code in rules:
        for k in keys:
            if re.search(r"\b" + re.escape(k), title):
                return code
    return None

changed = 0
new_codes = []
new_methods = []
for i, row in lookup.iterrows():
    code = row["isco_code"]
    method = row["method"]
    if method != "exact":
        rule_code = apply_rules(row["title_clean"])
        if rule_code is not None:
            if rule_code != code:
                changed = changed + 1
            code = rule_code
            method = "rule"
    new_codes.append(code)
    new_methods.append(method)

lookup["isco_code"] = new_codes
lookup["method"] = new_methods
lookup.to_csv("title_to_isco_final.csv", index=False)

print("rows changed by the rules:", changed)
print(lookup["method"].value_counts())

# how many postings now have a real ISCO code (top 1000 titles)?
check = lookup.merge(titles[["title_clean", "postings"]], on="title_clean", how="left")
check["postings"] = pd.to_numeric(check["postings"])
has_code = check[~check["isco_code"].isin(["NONE", "ERROR"])]
print("postings with an ISCO code:", round(has_code["postings"].sum() / check["postings"].sum() * 100, 1), "%")