import pandas as pd

lookup = pd.read_csv(r"C:\Users\waize\PyCharmMiscProject\title_to_isco_final.csv", dtype=str)

# corrections made by hand after checking the AI answers
# NONE means "no ISCO code fits" (too vague or not a job title)
fixes = {
    # data / AI jobs that the AI put in the wrong group
    "analytics engineer": "2511", "data quality analyst": "2511",
    "data visualization analyst": "2511", "data analyst internship": "2511",
    "data analytics consultant": "2511", "data analyst consultant": "2511",
    "consultant data analyst": "2511", "data quality engineer": "2511",
    "data management specialist": "2511", "data migration engineer": "2511",
    "data scientist internship": "2511", "databricks engineer": "2511",
    "ai product engineer": "2511", "informatiker": "2511",
    "technical architect": "2511", "azure data architect": "2511",
    "quantitative analyst": "2413", "quantitative researcher": "2413",
    "sql engineer": "2521",
    "data security engineer": "2529", "product security engineer": "2529",
    "master data specialist": "2511",
    # data / AI jobs the AI left as NONE
    "ml engineer": "2511", "ml": "2511", "aiml": "2511", "prompt engineer": "2511",
    "applied scientist": "2511", "decision scientist": "2511",
    "data specialist": "2511", "data visualization": "2511",
    "data visualization specialist": "2511", "data operations analyst": "2511",
    "data research analyst": "2511", "data support analyst": "2511",
    "data informatics analyst": "2511", "data governance analyst": "2511",
    "data operations engineer": "2511", "data support engineer": "2511",
    "data solutions engineer": "2511", "data governance engineer": "2511",
    "snowflake engineer": "2511", "platform engineer": "2511",
    "consultant data engineer": "2511", "data engineer consultant": "2511",
    "data engineering consultant": "2511", "consultant data science": "2511",
    "data science consultant": "2511", "consultant data analytics": "2511",
    "analytics consultant": "2511", "web analyst": "2511", "product analyst": "2511",
    "performance analyst": "2511", "reports analyst": "2511", "mis analyst": "2511",
    "information analyst": "2511", "analytics": "2511", "bi": "2511",
    "analyste de donn es": "2511", "ing nieur de donn es": "2511",
    "cient fico de datos": "2511",
    # managers and directors of data teams
    "data science manager": "1330", "manager data science": "1330",
    "manager of data science": "1330", "data analyst manager": "1330",
    "data analytics manager": "1330", "manager data analytics": "1330",
    "data engineering manager": "1330", "manager data engineering": "1330",
    "data engineer manager": "1330", "manager data engineer": "1330",
    "data scientist manager": "1330", "manager data scientist": "1330",
    "data science director": "1330", "director data science": "1330",
    "director of data science": "1330", "vp data science": "1330",
    "director of data engineering": "1330", "software engineering manager": "1330",
    # software and IT jobs
    "site reliability engineer": "2512", "aws engineer": "2512",
    "azure engineer": "2512", "cloud platform engineer": "2512",
    "net engineer": "2512", "ios engineer": "2512", "sw engineer": "2512",
    "python engineer": "2512", "java engineer": "2512", "mobile engineer": "2512",
    "android engineer": "2512", "firmware engineer": "2512",
    "test automation engineer": "2519", "qa automation engineer": "2519",
    "data qa engineer": "2519", "qa": "2519", "qa analyst": "2519", "quality analyst": "2519",
    "product support engineer": "3512", "technical support engineer": "3512",
    "customer support engineer": "3512", "application support engineer": "3512",
    "dynamic pc support": "3512", "technical support specialist": "3512",
    "ui": "2166", "brand designer": "2166", "product designer": "2166",
    # business, finance, sales, marketing
    "operations analyst": "2421", "operation analyst": "2421",
    "business operations analyst": "2421", "business process analyst": "2421",
    "business information analyst": "2421", "business performance analyst": "2421",
    "fp a analyst": "2413", "risk analyst": "2413", "pricing analyst": "2413",
    "treasury analyst": "2413", "risk manager": "1211",
    "account executive": "3322", "enterprise account executive": "3322",
    "mid market account executive": "3322", "founding account executive": "3322",
    "sales development representative": "3322", "inside sales representative": "3322",
    "outside sales representative": "3322", "strategic account manager": "3322",
    "enterprise account manager": "3322", "specialty account manager": "3322",
    "area sales manager": "1221", "performance marketing manager": "1221",
    "marketing": "2431", "product marketing": "2431", "growth marketing": "2431",
    "digital marketing analyst": "2431",
    "procurement manager": "1324", "structural engineer": "2142",
    "construction manager": "1323", "construction project manager": "1323",
    "credentialed tax accountant": "2411", "recruiter": "2423",
    "technical recruiter": "2423", "talent acquisition": "2423",
    "paralegal": "3411", "general counsel": "2611", "commercial counsel": "2611",
    "customer service representative": "4222", "cashier": "5230",
    "cook": "5120", "commis de cuisine": "5120", "commis de cuisine h": "5120",
    "care assistant": "5321", "aide soignant h": "5321", "aide soignant de nuit h": "5321",
    # too vague, or not a job title: no ISCO code
    "engineering manager": "NONE", "research analyst": "NONE", "scientist": "NONE",
    "research scientist": "NONE", "ai consultant": "NONE", "consulting": "NONE",
    "consultor": "NONE", "advisor": "NONE", "gnc engineer": "NONE",
    "business": "NONE", "mid": "NONE", "middle": "NONE", "job": "NONE",
    "expert": "NONE", "shift": "NONE", "production": "NONE", "project": "NONE",
    "program": "NONE", "growth": "NONE", "growth manager": "NONE",
    "member of technical": "NONE", "engineering": "NONE", "cdi": "NONE",
    "operations": "NONE", "product": "NONE", "research": "NONE", "apprentissage": "NONE",
    "student marketeer": "NONE", "binance accelerator program": "NONE",
    "information technology": "NONE", "management": "NONE", "commercial": "NONE",
    "designer": "NONE", "cloud": "NONE", "distributed cloud": "NONE",
    "technical program manager": "NONE", "program manager": "NONE",
    "technical project manager": "NONE", "project controls manager": "NONE",
    "assistant project manager": "NONE", "project controls engineer": "NONE",
    "crm analyst": "NONE", "sales analyst": "NONE", "data privacy analyst": "NONE",
    "data protection analyst": "NONE", "data governance": "NONE", "data quality": "NONE",
    "master data": "NONE", "engineer i": "NONE", "ms engineer": "NONE",
    "gtm engineer": "NONE", "c engineer": "NONE", "controls engineer": "NONE",
    "technique tests automatis s excellence dev": "NONE", "application engineer": "NONE",
    "technical solutions engineer": "NONE", "field application engineer": "NONE",
    "it systems engineer": "NONE", "field service engineer": "NONE",
    "service engineer": "NONE", "deployment strategist": "NONE",
    "account partner": "NONE", "client partner": "NONE",
    "territory development partner": "NONE", "client success manager": "NONE",
    "enterprise customer success manager": "NONE", "customer success": "NONE",
    "sales operations analyst": "NONE", "sales admin": "NONE", "sales service": "NONE",
    "go to market": "NONE", "commercial analyst": "NONE",
    "retail merchandising specialist": "NONE", "strategic finance": "NONE",
    "procurement analyst": "NONE", "supply chain": "NONE", "estimator": "NONE",
    "quantity surveyor": "NONE", "business operations": "NONE",
    "revenue operations manager": "NONE", "operations manager": "NONE",
    "operations engineer": "NONE", "group product manager": "NONE",
    "director of product": "NONE", "director of product management": "NONE",
    "director of engineering": "NONE", "quality manager": "NONE",
    "compliance manager": "NONE", "partnerships": "NONE", "planner": "NONE",
    "part time assistant manager": "NONE", "full time assistant manager": "NONE",
    "assistant store manager": "NONE", "general manager": "NONE",
    "automotive service manager": "NONE", "warehouse": "NONE", "medical analyst": "NONE",
    "analista de laboratorio": "NONE", "technician": "NONE",
    "ausbildung zum kaufmann f r versicherungen und finanzanlagen": "NONE",
    "producer": "NONE",
}

exact_titles = lookup.loc[lookup["method"] == "exact", "title_clean"].tolist()
missing = [t for t in fixes if t not in lookup["title_clean"].tolist()]
skipped = [t for t in fixes if t in exact_titles]
print("not found in the file (ignored):", len(missing))
print("exact matches left untouched:", len(skipped))

changed = 0
for i, row in lookup.iterrows():
    t = row["title_clean"]
    if t in fixes and row["method"] != "exact":
        if row["isco_code"] != fixes[t]:
            changed = changed + 1
        lookup.at[i, "isco_code"] = fixes[t]
        lookup.at[i, "method"] = "manual"

lookup.to_csv("title_to_isco_final2.csv", index=False)
print("rows changed by hand:", changed)
print(lookup["method"].value_counts())

# share of postings (top 1000 titles) that have a real ISCO code
try:
    titles = pd.read_csv(r"C:\Users\waize\PyCharmMiscProject\titles_tidied.csv")
    check = lookup.merge(titles[["title_clean", "postings"]], on="title_clean", how="left")
    check["postings"] = pd.to_numeric(check["postings"])
    has_code = check[~check["isco_code"].isin(["NONE", "ERROR"])]
    print("postings with an ISCO code:", round(has_code["postings"].sum() / check["postings"].sum() * 100, 1), "%")
except Exception as e:
    print("could not work out the postings share:", e)
