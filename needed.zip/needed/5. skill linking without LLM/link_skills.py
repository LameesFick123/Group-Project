import pandas as pd
import re

# 1. load the ESCO skills and build the pool of skill names
sk = pd.read_csv("esco_skills_clean.csv", dtype=str)

def tidy_skill(s):
    s = str(s).lower()
    s = re.sub(r"[-_]", " ", s)           # product-management -> product management
    s = re.sub(r"\s+", " ", s).strip()
    return s

p1 = sk[["skill_uri", "skill"]].rename(columns={"skill": "label"})
p2 = sk[["skill_uri", "altLabels"]].dropna()
p2["label"] = p2["altLabels"].str.split("\n")
p2 = p2.explode("label")[["skill_uri", "label"]]

pool = pd.concat([p1, p2]).dropna()
pool["label"] = pool["label"].apply(tidy_skill)
pool = pool[pool["label"] != ""].drop_duplicates()

# only keep labels that point to ONE skill (so the match is not ambiguous)
counts_per_label = pool.groupby("label")["skill_uri"].agg(["nunique", "first"]).reset_index()
pool = counts_per_label[counts_per_label["nunique"] == 1][["label", "first"]]
pool = pool.rename(columns={"first": "skill_uri"})
print("skill pool size:", len(pool))

# 2. load the jobs and turn the skills column into a list of skills
jobs = pd.read_csv(r"C:\Users\waize\PyCharmMiscProject\jobs_all.csv")
jobs = jobs.dropna(subset=["skills"])

def split_skills(text):
    text = str(text)
    if "'" in text:                                   # looks like ['python', 'sql'] or ['a' 'b']
        found = re.findall(r"'([^']*)'", text)
    else:                                             # looks like Python, SQL, AWS or [a, b]
        found = text.strip("[]").split(",")
    return [tidy_skill(x) for x in found if x.strip() != ""]

jobs["skill_list"] = jobs["skills"].apply(split_skills)

# 3. count every skill
all_skills = jobs["skill_list"].explode().dropna()
skill_counts = all_skills.value_counts()
print("unique skills:", len(skill_counts))
print("total skill mentions:", len(all_skills))

# 4. exact match against ESCO
table = pd.DataFrame({"skill_clean": skill_counts.index, "mentions": skill_counts.values})
exact = table.merge(pool, left_on="skill_clean", right_on="label", how="left")

matched = exact[exact["skill_uri"].notna()]
unmatched = exact[exact["skill_uri"].isna()]

print("skills matched exactly:", len(matched))
print("mentions covered by exact matches:", round(matched["mentions"].sum() / len(all_skills) * 100, 1), "%")

print()
print("30 most common UNMATCHED skills:")
print(unmatched[["skill_clean", "mentions"]].head(30).to_string(index=False))

matched[["skill_clean", "skill_uri"]].to_csv("skill_to_esco_exact.csv", index=False)
unmatched[["skill_clean", "mentions"]].to_csv("skills_for_llm.csv", index=False)