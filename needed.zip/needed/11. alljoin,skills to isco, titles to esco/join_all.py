import pandas as pd
import re

# the same tidy tools we used before
remove_words = ["senior", "sr", "junior", "jr", "lead", "principal", "staff",
                "associate", "intern", "trainee", "head of", "chief",
                "ii", "iii", "iv"]

def tidy(title):
    t = str(title).lower()
    t = re.sub(r"\(.*?\)|\[.*?\]", " ", t)
    t = re.split(r" - | – | — | \| |,|/", t)[0]
    t = re.sub(r"[^a-z ]", " ", t)
    for w in remove_words:
        t = re.sub(r"\b" + w + r"\b", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t

def tidy_skill(s):
    s = str(s).lower()
    s = re.sub(r"[-_]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s

def split_skills(text):
    text = str(text)
    if "'" in text:
        found = re.findall(r"'([^']*)'", text)
    else:
        found = text.strip("[]").split(",")
    return [tidy_skill(x) for x in found if x.strip() != ""]

# 1. load the job table
jobs = pd.read_csv(r"C:\Users\waize\PyCharmMiscProject\jobs_all.csv", dtype=str)
print("job rows:", len(jobs))

# the year is the first 4 digits of the date (works for all 3 date styles)
jobs["year"] = jobs["posting_date"].str.extract(r"^(\d{4})")[0]

# 2. add the ISCO code
t_lookup = pd.read_csv("title_to_isco_final2.csv", dtype=str)
t_lookup = t_lookup[~t_lookup["isco_code"].isin(["NONE", "ERROR"])]
t_map = dict(zip(t_lookup["title_clean"], t_lookup["isco_code"]))

# tidy each different title only once (much faster)
tidy_map = {t: tidy(t) for t in jobs["job_title"].dropna().unique()}
jobs["title_clean"] = jobs["job_title"].map(tidy_map)
jobs["isco_code"] = jobs["title_clean"].map(t_map)

# 3. split the skills
s_lookup = pd.read_csv(r"C:\Users\waize\PyCharmMiscProject\skill_to_esco_final.csv", dtype=str)
s_map = dict(zip(s_lookup["skill_clean"], s_lookup["skill_uri"]))

split_map = {s: split_skills(s) for s in jobs["skills"].dropna().unique()}
jobs["skill_list"] = jobs["skills"].map(split_map)

# save the linked job table
jobs[["year", "job_title", "title_clean", "isco_code", "skills"]].to_csv("jobs_linked.csv", index=False)

# 4. one row per skill mention
slim = jobs[["year", "isco_code", "skill_list"]].dropna(subset=["year", "skill_list"])
slim = slim.explode("skill_list").rename(columns={"skill_list": "skill_clean"})
slim = slim.dropna(subset=["skill_clean"])
slim["skill_uri"] = slim["skill_clean"].map(s_map)

# 5. count things (these tables are used for the analysis)
skill_year = slim.groupby(["year", "skill_clean", "skill_uri"], dropna=False).size().reset_index(name="mentions")
skill_year.to_csv("skill_counts_by_year.csv", index=False)

isco_year = jobs.dropna(subset=["year", "isco_code"]).groupby(["year", "isco_code"]).size().reset_index(name="postings")
isco_year.to_csv("isco_counts_by_year.csv", index=False)

skill_isco = slim.dropna(subset=["isco_code"]).groupby(["year", "isco_code", "skill_clean", "skill_uri"], dropna=False).size().reset_index(name="mentions")
skill_isco.to_csv("skill_isco_counts_by_year.csv", index=False)

# 6. print a summary
print("years found:", sorted(jobs["year"].dropna().unique()))
print("postings with an ISCO code:", round(jobs["isco_code"].notna().mean() * 100, 1), "%")
print("skill mentions:", len(slim))
print("skill mentions linked to ESCO:", round(slim["skill_uri"].notna().mean() * 100, 1), "%")
print()
print("10 most common skills:")
print(slim["skill_clean"].value_counts().head(10))
print()
print("10 most common ISCO codes:")
print(jobs["isco_code"].value_counts().head(10))
