import pandas as pd

#load the cleaned framework files (saved in your PyCharm project folder)
isco = pd.read_csv("isco_clean.csv", dtype=str)
occ = pd.read_csv("esco_occupations_clean.csv", dtype=str)

# build the pool of titles, each with an ISCO code
pool1 = isco.rename(columns={"isco_title": "label"})[["isco_code", "label"]]
pool2 = occ.rename(columns={"occupation": "label"})[["isco_code", "label"]]

# ESCO synonyms are in one cell separated by line breaks, so split them into rows
alt = occ[["isco_code", "altLabels"]].dropna()
alt["label"] = alt["altLabels"].str.split("\n")
alt = alt.explode("label")[["isco_code", "label"]]

pool = pd.concat([pool1, pool2, alt]).dropna()
pool["label"] = pool["label"].str.lower().str.strip()
pool = pool.drop_duplicates().reset_index(drop=True)
print("pool size:", len(pool))

#  get the unique job titles
jobs = pd.read_csv(r"C:\Users\waize\PyCharmMiscProject\jobs_all.csv")
jobs["title_clean"] = jobs["job_title"].str.lower().str.strip()
titles = pd.DataFrame({"title_clean": jobs["title_clean"].dropna().unique()})
print("unique titles:", len(titles))

# exact match
exact = titles.merge(pool.drop_duplicates("label"), left_on="title_clean", right_on="label", how="left")
matched = exact[exact["isco_code"].notna()][["title_clean", "isco_code"]]
rest = exact[exact["isco_code"].isna()][["title_clean"]]
print("exact matched:", len(matched))
print("left for LLM:", len(rest))

matched.to_csv("titles_exact_matched.csv", index=False)
rest.to_csv("titles_for_llm.csv", index=False)