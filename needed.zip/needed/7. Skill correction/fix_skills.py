import pandas as pd

lookup = pd.read_csv("skill_to_esco.csv")
sk = pd.read_csv("esco_skills_clean.csv")

# find the ESCO ID for "use spreadsheets software"
sheet_uri = sk.loc[sk["skill"] == "use spreadsheets software", "skill_uri"].iloc[0]

# wrong matches: remove the link
for s in ["airflow", "outlook", "t sql", "express", "mlr"]:
    lookup.loc[lookup["skill_clean"] == s, "skill_uri"] = None

# missed matches: add the right link
for s in ["excel", "spreadsheet"]:
    lookup = lookup[lookup["skill_clean"] != s]
    lookup = pd.concat([lookup, pd.DataFrame({"skill_clean": [s], "skill_uri": [sheet_uri]})])

lookup.to_csv("skill_to_esco_final.csv", index=False)
print("linked:", lookup["skill_uri"].notna().sum(), "of", len(lookup))