import pandas as pd
import re
import os
import ollama
from rapidfuzz import process, fuzz

MODEL = "qwen2.5:7b"
TEST = False       # True = only 20 titles. Change to False for the full run
TOP = 1000        # how many of the most common titles to map

remove_words = ["senior", "sr", "junior", "jr", "lead", "principal", "staff",
                "associate", "intern", "trainee", "head of", "chief",
                "ii", "iii", "iv"]

def tidy(title):
    t = str(title).lower()
    t = re.sub(r"\(.*?\)|\[.*?\]", " ", t)
    t = re.split(r" - | – | — | \| |,|/", t)[0]
    t = re.sub(r"[^a-z ]", " ", t)
    for w in remove_words:
        t = re.sub(r"\b" + w + r"\b", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t

# pool of titles with ISCO codes
isco = pd.read_csv("isco_clean.csv", dtype=str)
occ = pd.read_csv("esco_occupations_clean.csv", dtype=str)

pool1 = isco.rename(columns={"isco_title": "label"})[["isco_code", "label"]]
pool2 = occ.rename(columns={"occupation": "label"})[["isco_code", "label"]]
alt = occ[["isco_code", "altLabels"]].dropna()
alt["label"] = alt["altLabels"].str.split("\n")
alt = alt.explode("label")[["isco_code", "label"]]

pool = pd.concat([pool1, pool2, alt]).dropna()
pool["label"] = pool["label"].apply(tidy)
pool = pool[pool["label"] != ""].drop_duplicates().reset_index(drop=True)

# the titles to map
titles = pd.read_csv("titles_tidied.csv").head(TOP)

# exact match, only if the label has exactly ONE isco code
codes_per_label = pool.groupby("label")["isco_code"].agg(["nunique", "first"]).reset_index()
unique_labels = codes_per_label[codes_per_label["nunique"] == 1]
exact = titles.merge(unique_labels, left_on="title_clean", right_on="label", how="inner")
matched = exact[["title_clean", "first"]].rename(columns={"first": "isco_code"})
matched["method"] = "exact"

rest = titles[~titles["title_clean"].isin(matched["title_clean"])]
print("exact matched:", len(matched), "| for the LLM:", len(rest))

labels = pool["label"].tolist()
codes = pool["isco_code"].tolist()

# 10 closest candidates (one per ISCO code)
def get_candidates(title):
    results = process.extract(title, labels, scorer=fuzz.token_sort_ratio, limit=60)
    seen = []
    out = []
    for label, score, i in results:
        if codes[i] not in seen:
            seen.append(codes[i])
            out.append((codes[i], label))
    return out[:10]

code_title = dict(zip(isco["isco_code"], isco["isco_title"]))

VAGUE = ["manager", "director", "engineer", "analyst", "consultant", "data", "ai",
         "specialist", "officer", "associate", "developer", "executive", "lead",
         "administrator", "coordinator", "assistant", "architect"]

def ask_llm(title, cands):
    options = ""
    for n, c in enumerate(cands):
        options += str(n + 1) + ". " + c[1] + "\n"
    prompt = ("Job title: " + title + "\n\nCandidate occupations:\n" + options +
              "\nWhich candidate is the same kind of job as the job title? "
              "Only choose a candidate if you are confident it is a good match. "
              "Do not guess. If no candidate fits well, reply NONE. "
              "Reply with only the number or NONE.")
    reply = ollama.chat(model=MODEL,
                        messages=[{"role": "user", "content": prompt}],
                        options={"temperature": 0})
    answer = reply["message"]["content"].strip()
    m = re.match(r"\d+", answer)
    if m and 1 <= int(m.group()) <= len(cands):
        return cands[int(m.group()) - 1][0]
    return "NONE"

if TEST:
    rest = rest.head(20)

# resume from saved progress if it exists
done = {}
if os.path.exists("llm_title_progress.csv") and not TEST:
    old = pd.read_csv("llm_title_progress.csv", dtype=str)
    done = dict(zip(old["title_clean"], old["isco_code"]))

results = []
for n, title in enumerate(rest["title_clean"]):
    if title in done:
        results.append({"title_clean": title, "isco_code": done[title], "method": "llm"})
        continue
    if title in VAGUE:
        results.append({"title_clean": title, "isco_code": "NONE", "method": "vague", "candidates": ""})
        print(n, title, "-> NONE (too vague)")
        continue
    cands = get_candidates(title)
    code = ask_llm(title, cands)
    results.append({"title_clean": title, "isco_code": code, "method": "llm",
                    "candidates": " | ".join([c[0] + " " + c[1] for c in cands])})
    print(n, title, "->", code, code_title.get(code, ""))
    if n % 50 == 0:
        pd.DataFrame(results).to_csv("llm_title_progress.csv", index=False)

llm_matched = pd.DataFrame(results)
lookup = pd.concat([matched, llm_matched])
lookup.to_csv("title_to_isco.csv", index=False)
print(lookup["method"].value_counts())