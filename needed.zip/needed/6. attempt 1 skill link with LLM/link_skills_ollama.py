import pandas as pd
import re
import ollama
from rapidfuzz import process, fuzz

MODEL = "qwen2.5:7b"
TEST = False     # True = only 10 skills. Change to False for all of them

def tidy_skill(s):
    s = str(s).lower()
    s = re.sub(r"[-_]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s

# pool of ESCO skill names (keeps every label)
sk = pd.read_csv("esco_skills_clean.csv", dtype=str)

p1 = sk[["skill_uri", "skill"]].copy()
p1["label"] = p1["skill"]
p2 = sk[["skill_uri", "skill", "altLabels"]].dropna()
p2["label"] = p2["altLabels"].str.split("\n")
p2 = p2.explode("label")[["skill_uri", "skill", "label"]]

pool = pd.concat([p1[["skill_uri", "skill", "label"]], p2]).dropna()
pool["label"] = pool["label"].apply(tidy_skill)
pool = pool[pool["label"] != ""].drop_duplicates().reset_index(drop=True)

labels = pool["label"].tolist()
uris = pool["skill_uri"].tolist()
names = pool["skill"].tolist()

# 5 closest candidates (one per ESCO skill)
def get_candidates(skill):
    results = process.extract(skill, labels, scorer=fuzz.WRatio, limit=40)
    seen = []
    out = []
    for label, score, i in results:
        if uris[i] not in seen:
            seen.append(uris[i])
            out.append((uris[i], names[i]))
    return out[:5]

# ask the local LLM
def ask_llm(skill, cands):
    options = ""
    for n, c in enumerate(cands):
        options += str(n + 1) + ". " + c[1] + "\n"
    prompt = ("Skill from a job posting: " + skill + "\n\nCandidate skills:\n" + options +
              "\nDoes any candidate mean the same skill or tool? "
              "Reply with only the number, or NONE if none fit.")
    reply = ollama.chat(model=MODEL,
                        messages=[{"role": "user", "content": prompt}],
                        options={"temperature": 0})
    answer = reply["message"]["content"].strip()
    m = re.match(r"\d", answer)
    if m and 1 <= int(m.group()) <= len(cands):
        return cands[int(m.group()) - 1]
    return (None, None)

todo = pd.read_csv("skills_for_llm.csv")
if TEST:
    todo = todo.head(10)

results = []
for skill in todo["skill_clean"]:
    cands = get_candidates(skill)
    uri, name = ask_llm(skill, cands)
    results.append({"skill_clean": skill, "skill_uri": uri, "esco_skill": name,
                    "candidates": " | ".join([c[1] for c in cands])})
    print(skill, "->", name)

llm_matched = pd.DataFrame(results)
llm_matched.to_csv("skill_to_esco_llm.csv", index=False)

exact = pd.read_csv("skill_to_esco_exact.csv")
lookup = pd.concat([exact, llm_matched[["skill_clean", "skill_uri"]]])
lookup.to_csv("skill_to_esco.csv", index=False)
print("skills linked:", lookup["skill_uri"].notna().sum(), "of", len(lookup))

